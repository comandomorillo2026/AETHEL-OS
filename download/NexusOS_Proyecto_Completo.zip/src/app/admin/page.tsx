'use client';

import React from 'react';
import { AuthProvider, useAuth } from '@/lib/auth';
import { LoginForm } from '@/components/auth/login-form';
import { AdminDashboard } from '@/components/admin/admin-dashboard';

function AdminContent() {
  const { isAuthenticated, isSuperAdmin, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#050410]">
        <div className="text-center">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#F0B429] to-[#d97706] animate-pulse mx-auto" />
          <p className="text-[#9D7BEA] mt-4">Cargando Torre de Control...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated || !isSuperAdmin) {
    return <LoginForm onSuccess={() => {}} />;
  }

  return <AdminDashboard />;
}

export default function AdminPage() {
  return (
    <AuthProvider>
      <AdminContent />
    </AuthProvider>
  );
}
