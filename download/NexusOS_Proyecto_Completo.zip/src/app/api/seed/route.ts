import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET() {
  try {
    // Seed Industries
    const industries = [
      {
        slug: 'bakery',
        nameEn: 'Bakery & Pastry',
        nameEs: 'Panadería y Pastelería',
        icon: '🧁',
        descriptionEn: 'Manage orders, recipes, clients & POS in one place',
        descriptionEs: 'Gestiona pedidos, recetas, clientes y POS en un solo lugar',
        status: 'active',
        sortOrder: 1,
      },
      {
        slug: 'clinic',
        nameEn: 'Clinics & Wellness',
        nameEs: 'Clínicas y Bienestar',
        icon: '🏥',
        descriptionEn: 'Appointments, patient records, billing & compliance',
        descriptionEs: 'Citas, historiales de pacientes, facturación y cumplimiento',
        status: 'active',
        sortOrder: 2,
      },
      {
        slug: 'salon',
        nameEn: 'Salon & Spa',
        nameEs: 'Salón y Spa',
        icon: '💇',
        descriptionEn: 'Bookings, stylists, memberships & gift cards',
        descriptionEs: 'Reservas, estilistas, membresías y tarjetas de regalo',
        status: 'active',
        sortOrder: 3,
      },
      {
        slug: 'retail',
        nameEn: 'Retail & Boutique',
        nameEs: 'Retail y Boutique',
        icon: '🛍️',
        descriptionEn: 'Inventory, POS, multi-branch & loyalty programs',
        descriptionEs: 'Inventario, POS, multi-sucursal y programas de lealtad',
        status: 'active',
        sortOrder: 4,
      },
      {
        slug: 'hospitality',
        nameEn: 'Bars & Hospitality',
        nameEs: 'Bares y Hospitalidad',
        icon: '🍸',
        descriptionEn: 'Table management, tabs, events & staff scheduling',
        descriptionEs: 'Gestión de mesas, cuentas, eventos y horarios de personal',
        status: 'coming_soon',
        sortOrder: 5,
      },
      {
        slug: 'events',
        nameEn: 'Events & Venues',
        nameEs: 'Eventos y Locales',
        icon: '🎉',
        descriptionEn: 'Bookings, client contracts, vendor management',
        descriptionEs: 'Reservas, contratos de clientes, gestión de proveedores',
        status: 'coming_soon',
        sortOrder: 6,
      },
      {
        slug: 'professional',
        nameEn: 'Professional Services',
        nameEs: 'Servicios Profesionales',
        icon: '💼',
        descriptionEn: 'CRM, proposals, billing & time tracking',
        descriptionEs: 'CRM, propuestas, facturación y seguimiento de tiempo',
        status: 'coming_soon',
        sortOrder: 7,
      },
      {
        slug: 'legal',
        nameEn: 'Legal',
        nameEs: 'Legal',
        icon: '⚖️',
        descriptionEn: 'Matter management, billing, compliance & documents',
        descriptionEs: 'Gestión de casos, facturación, cumplimiento y documentos',
        status: 'coming_soon',
        sortOrder: 8,
      },
      {
        slug: 'insurance',
        nameEn: 'Insurance',
        nameEs: 'Seguros',
        icon: '🛡️',
        descriptionEn: 'Policy tracking, renewals, client portal & claims',
        descriptionEs: 'Seguimiento de pólizas, renovaciones, portal de clientes y reclamos',
        status: 'coming_soon',
        sortOrder: 9,
      },
      {
        slug: 'hse',
        nameEn: 'HSE & Offshore',
        nameEs: 'HSE y Offshore',
        icon: '🔧',
        descriptionEn: 'Compliance logs, incident reports, certifications',
        descriptionEs: 'Registros de cumplimiento, reportes de incidentes, certificaciones',
        status: 'coming_soon',
        sortOrder: 10,
      },
      {
        slug: 'funeral',
        nameEn: 'Funeral Services',
        nameEs: 'Servicios Funerarios',
        icon: '🕊️',
        descriptionEn: 'Family management, arrangements, scheduling & billing',
        descriptionEs: 'Gestión familiar, arreglos, programación y facturación',
        status: 'coming_soon',
        sortOrder: 11,
      },
    ];

    for (const industry of industries) {
      await db.industry.upsert({
        where: { slug: industry.slug },
        update: industry,
        create: industry,
      });
    }

    // Seed Plans
    const plans = [
      {
        slug: 'starter',
        nameEn: 'STARTER',
        nameEs: 'STARTER',
        tier: 'starter',
        priceMonthlyTtd: 500,
        priceAnnualTtd: 400,
        priceBiannualTtd: 450,
        maxUsers: 3,
        maxBranches: 1,
        badgeEn: 'GET STARTED',
        badgeEs: 'COMENZAR',
        badgeColor: 'violet',
      },
      {
        slug: 'growth',
        nameEn: 'GROWTH ENGINE',
        nameEs: 'GROWTH ENGINE',
        tier: 'growth',
        priceMonthlyTtd: 1200,
        priceAnnualTtd: 960,
        priceBiannualTtd: 1080,
        maxUsers: 10,
        maxBranches: 3,
        badgeEn: 'MOST POPULAR',
        badgeEs: 'MÁS POPULAR',
        badgeColor: 'gold',
      },
      {
        slug: 'premium',
        nameEn: 'PREMIUM ELITE',
        nameEs: 'PREMIUM ELITE',
        tier: 'premium',
        priceMonthlyTtd: 2500,
        priceAnnualTtd: 2000,
        priceBiannualTtd: 2250,
        maxUsers: 50,
        maxBranches: 10,
        badgeEn: 'ENTERPRISE GRADE',
        badgeEs: 'GRADO EMPRESARIAL',
        badgeColor: 'fuchsia',
      },
    ];

    for (const plan of plans) {
      await db.plan.upsert({
        where: { slug: plan.slug },
        update: plan,
        create: plan,
      });
    }

    // Seed Coupon
    await db.salesCoupon.upsert({
      where: { code: 'EARLYBIRD' },
      update: {},
      create: {
        code: 'EARLYBIRD',
        discountType: 'fixed_ttd',
        discountValue: 250,
        appliesTo: 'activation',
        maxUses: 50,
        timesUsed: 0,
        status: 'active',
        description: 'Early bird discount - first 50 clients',
      },
    });

    // Seed System Settings
    const settings = [
      { key: 'currency_ttd_usd_rate', value: '6.75', description: 'TTD to USD exchange rate', isPublic: true },
      { key: 'activation_fee_ttd', value: '1250', description: 'One-time activation fee', isPublic: true },
      { key: 'activation_fee_regular_ttd', value: '2500', description: 'Regular activation fee', isPublic: true },
      { key: 'early_bird_limit', value: '50', description: 'Early bird discount limit', isPublic: false },
    ];

    for (const setting of settings) {
      await db.systemSetting.upsert({
        where: { key: setting.key },
        update: setting,
        create: setting,
      });
    }

    return NextResponse.json({
      success: true,
      message: 'Database seeded successfully',
      data: {
        industries: industries.length,
        plans: plans.length,
        coupons: 1,
        settings: settings.length,
      },
    });
  } catch (error) {
    console.error('Error seeding database:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to seed database' },
      { status: 500 }
    );
  }
}
