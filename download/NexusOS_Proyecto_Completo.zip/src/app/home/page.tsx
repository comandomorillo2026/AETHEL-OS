'use client';

import React from 'react';
import Link from 'next/link';
import { 
  Shield,
  ArrowRight,
  Globe,
  Hospital, 
  Heart,
  Settings,
  Users,
  Calendar,
  DollarSign,
  Pill,
  FlaskConical,
  Package,
  BarChart3,
  User,
  Scissors,
  Scale
} from 'lucide-react';

export default function HubPage() {
  return (
    <div className="min-h-screen bg-[#050410]">
      {/* Aurora Background */}
      <div className="aurora-bg" />
      
      {/* Header */}
      <header className="relative z-10 border-b border-[rgba(167,139,250,0.1)] bg-[#0A0820]/80 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#6C3FCE] to-[#C026D3] flex items-center justify-center">
              <Shield className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-[#EDE9FE]" style={{ fontFamily: 'var(--font-cormorant)' }}>
                NexusOS
              </h1>
              <p className="text-xs text-[#9D7BEA]">Sistema de Gestión Empresarial</p>
            </div>
          </div>
          <Link 
            href="/login" 
            className="px-4 py-2 rounded-lg bg-gradient-to-r from-[#6C3FCE] to-[#C026D3] text-white text-sm font-medium hover:opacity-90 transition-opacity"
          >
            Iniciar Sesión
          </Link>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative z-10 max-w-7xl mx-auto px-4 py-8">
        {/* Welcome Section */}
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold text-[#EDE9FE] mb-4" style={{ fontFamily: 'var(--font-cormorant)' }}>
            Centro de Control
          </h2>
          <p className="text-lg text-[#9D7BEA] max-w-2xl mx-auto">
            Accede a todos los módulos del sistema desde un solo lugar. 
            Selecciona el área que necesitas gestionar.
          </p>
        </div>

        {/* Main Systems Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          
          {/* Portal de Pacientes */}
          <Link href="/portal-paciente" className="group">
            <div className="p-6 rounded-xl bg-[rgba(108,63,206,0.05)] border border-[rgba(167,139,250,0.1)] backdrop-blur-lg h-full hover:border-[#F87171]/50 transition-all cursor-pointer">
              <div className="flex items-start justify-between mb-4">
                <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-[#F87171] to-[#dc2626] flex items-center justify-center">
                  <User className="w-7 h-7 text-white" />
                </div>
                <ArrowRight className="w-5 h-5 text-[#9D7BEA] group-hover:translate-x-1 transition-transform" />
              </div>
              <h3 className="text-lg font-semibold text-[#EDE9FE] mb-2">Portal de Pacientes</h3>
              <p className="text-sm text-[#9D7BEA] mb-4">
                Citas, resultados, recetas, facturas.
              </p>
              <div className="flex flex-wrap gap-2">
                <span className="text-xs px-2 py-1 rounded bg-[#F87171]/20 text-[#F87171]">Autoservicio</span>
              </div>
            </div>
          </Link>

          {/* Portal de Ventas */}
          <Link href="/" className="group">
            <div className="p-6 rounded-xl bg-[rgba(108,63,206,0.05)] border border-[rgba(167,139,250,0.1)] backdrop-blur-lg h-full hover:border-[#6C3FCE]/50 transition-all cursor-pointer">
              <div className="flex items-start justify-between mb-4">
                <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-[#6C3FCE] to-[#C026D3] flex items-center justify-center">
                  <Globe className="w-7 h-7 text-white" />
                </div>
                <ArrowRight className="w-5 h-5 text-[#9D7BEA] group-hover:translate-x-1 transition-transform" />
              </div>
              <h3 className="text-lg font-semibold text-[#EDE9FE] mb-2">Portal de Ventas</h3>
              <p className="text-sm text-[#9D7BEA] mb-4">
                Sitio público para captar clientes.
              </p>
              <div className="flex flex-wrap gap-2">
                <span className="text-xs px-2 py-1 rounded bg-[#6C3FCE]/20 text-[#B197FC]">Marketing</span>
              </div>
            </div>
          </Link>

          {/* Torre de Control */}
          <Link href="/admin" className="group">
            <div className="p-6 rounded-xl bg-[rgba(108,63,206,0.05)] border border-[rgba(167,139,250,0.1)] backdrop-blur-lg h-full hover:border-[#F0B429]/50 transition-all cursor-pointer">
              <div className="flex items-start justify-between mb-4">
                <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-[#F0B429] to-[#d97706] flex items-center justify-center">
                  <Shield className="w-7 h-7 text-white" />
                </div>
                <ArrowRight className="w-5 h-5 text-[#9D7BEA] group-hover:translate-x-1 transition-transform" />
              </div>
              <h3 className="text-lg font-semibold text-[#EDE9FE] mb-2">Torre de Control</h3>
              <p className="text-sm text-[#9D7BEA] mb-4">
                Panel de administración del dueño.
              </p>
              <div className="flex flex-wrap gap-2">
                <span className="text-xs px-2 py-1 rounded bg-[#F0B429]/20 text-[#F0B429]">Admin</span>
              </div>
            </div>
          </Link>

          {/* Sistema de Clínica */}
          <Link href="/clinic" className="group">
            <div className="p-6 rounded-xl bg-[rgba(108,63,206,0.05)] border border-[rgba(167,139,250,0.1)] backdrop-blur-lg h-full hover:border-[#22D3EE]/50 transition-all cursor-pointer">
              <div className="flex items-start justify-between mb-4">
                <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-[#22D3EE] to-[#3B82F6] flex items-center justify-center">
                  <Hospital className="w-7 h-7 text-white" />
                </div>
                <ArrowRight className="w-5 h-5 text-[#9D7BEA] group-hover:translate-x-1 transition-transform" />
              </div>
              <h3 className="text-lg font-semibold text-[#EDE9FE] mb-2">Sistema de Clínica</h3>
              <p className="text-sm text-[#9D7BEA] mb-4">
                Pacientes, citas, facturación.
              </p>
              <div className="flex flex-wrap gap-2">
                <span className="text-xs px-2 py-1 rounded bg-[#22D3EE]/20 text-[#22D3EE]">Completo</span>
              </div>
            </div>
          </Link>

          {/* Portal de Enfermería */}
          <Link href="/nurse" className="group">
            <div className="p-6 rounded-xl bg-[rgba(108,63,206,0.05)] border border-[rgba(167,139,250,0.1)] backdrop-blur-lg h-full hover:border-[#34D399]/50 transition-all cursor-pointer">
              <div className="flex items-start justify-between mb-4">
                <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-[#34D399] to-[#059669] flex items-center justify-center">
                  <Heart className="w-7 h-7 text-white" />
                </div>
                <ArrowRight className="w-5 h-5 text-[#9D7BEA] group-hover:translate-x-1 transition-transform" />
              </div>
              <h3 className="text-lg font-semibold text-[#EDE9FE] mb-2">Portal de Enfermería</h3>
              <p className="text-sm text-[#9D7BEA] mb-4">
                SBAR, signos vitales, MAR.
              </p>
              <div className="flex flex-wrap gap-2">
                <span className="text-xs px-2 py-1 rounded bg-[#34D399]/20 text-[#34D399]">SBAR</span>
              </div>
            </div>
          </Link>

          {/* Sistema de Salones de Belleza */}
          <Link href="/beauty" className="group">
            <div className="p-6 rounded-xl bg-[rgba(108,63,206,0.05)] border border-[rgba(167,139,250,0.1)] backdrop-blur-lg h-full hover:border-[#EC4899]/50 transition-all cursor-pointer">
              <div className="flex items-start justify-between mb-4">
                <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-[#EC4899] to-[#8B5CF6] flex items-center justify-center">
                  <Scissors className="w-7 h-7 text-white" />
                </div>
                <ArrowRight className="w-5 h-5 text-[#9D7BEA] group-hover:translate-x-1 transition-transform" />
              </div>
              <h3 className="text-lg font-semibold text-[#EDE9FE] mb-2">Salones de Belleza</h3>
              <p className="text-sm text-[#9D7BEA] mb-4">
                Citas, POS, finanzas, contabilidad.
              </p>
              <div className="flex flex-wrap gap-2">
                <span className="text-xs px-2 py-1 rounded bg-[#EC4899]/20 text-[#EC4899]">Beauty</span>
              </div>
            </div>
          </Link>

          {/* Sistema de Bufetes de Abogados - NUEVO */}
          <Link href="/lawfirm" className="group">
            <div className="p-6 rounded-xl bg-[rgba(108,63,206,0.05)] border border-[rgba(167,139,250,0.1)] backdrop-blur-lg h-full hover:border-[#C4A35A]/50 transition-all cursor-pointer">
              <div className="flex items-start justify-between mb-4">
                <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-[#1E3A5F] to-[#C4A35A] flex items-center justify-center">
                  <Scale className="w-7 h-7 text-white" />
                </div>
                <ArrowRight className="w-5 h-5 text-[#9D7BEA] group-hover:translate-x-1 transition-transform" />
              </div>
              <h3 className="text-lg font-semibold text-[#EDE9FE] mb-2">Bufetes de Abogados</h3>
              <p className="text-sm text-[#9D7BEA] mb-4">
                Casos, clientes, documentos legales.
              </p>
              <div className="flex flex-wrap gap-2">
                <span className="text-xs px-2 py-1 rounded bg-[#C4A35A]/20 text-[#C4A35A]">Nuevo</span>
              </div>
            </div>
          </Link>

        </div>

        {/* Pricing Section */}
        <div className="p-6 rounded-xl bg-[rgba(108,63,206,0.05)] border border-[rgba(167,139,250,0.1)] backdrop-blur-lg mb-8">
          <h3 className="text-lg font-semibold text-[#EDE9FE] mb-6 text-center">Planes por Cantidad de Enfermeras</h3>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {/* Starter */}
            <div className="p-4 rounded-lg bg-[rgba(108,63,206,0.07)] border border-[rgba(167,139,250,0.1)]">
              <h4 className="font-medium text-[#EDE9FE] mb-1">STARTER</h4>
              <p className="text-2xl font-bold text-[#9D7BEA]">TT$800<span className="text-sm font-normal">/mes</span></p>
              <p className="text-xs text-[rgba(167,139,250,0.5)] mb-3">1-2 enfermeras</p>
              <ul className="text-xs text-[#9D7BEA] space-y-1">
                <li>✓ Hasta 200 pacientes</li>
                <li>✓ Citas básicas</li>
                <li>✓ Facturación simple</li>
                <li className="text-[rgba(167,139,250,0.4)]">✗ Portal Enfermería</li>
              </ul>
            </div>
            
            {/* Growth */}
            <div className="p-4 rounded-lg bg-[rgba(108,63,206,0.1)] border border-[#6C3FCE]/30 relative">
              <span className="absolute -top-2 left-4 px-2 py-0.5 rounded bg-[#F0B429] text-[#050410] text-xs font-bold">POPULAR</span>
              <h4 className="font-medium text-[#EDE9FE] mb-1">GROWTH</h4>
              <p className="text-2xl font-bold text-[#22D3EE]">TT$1,500<span className="text-sm font-normal">/mes</span></p>
              <p className="text-xs text-[rgba(167,139,250,0.5)] mb-3">3-5 enfermeras</p>
              <ul className="text-xs text-[#9D7BEA] space-y-1">
                <li>✓ Pacientes ilimitados</li>
                <li>✓ Portal de Enfermería</li>
                <li>✓ Laboratorio</li>
                <li>✓ Inventario</li>
              </ul>
            </div>
            
            {/* Premium */}
            <div className="p-4 rounded-lg bg-[rgba(108,63,206,0.07)] border border-[rgba(167,139,250,0.1)]">
              <h4 className="font-medium text-[#EDE9FE] mb-1">PREMIUM</h4>
              <p className="text-2xl font-bold text-[#34D399]">TT$2,800<span className="text-sm font-normal">/mes</span></p>
              <p className="text-xs text-[rgba(167,139,250,0.5)] mb-3">6-10 enfermeras</p>
              <ul className="text-xs text-[#9D7BEA] space-y-1">
                <li>✓ Todo en GROWTH</li>
                <li>✓ Telemedicina</li>
                <li>✓ Recetas electrónicas</li>
                <li>✓ Portal Paciente completo</li>
              </ul>
            </div>
            
            {/* Enterprise */}
            <div className="p-4 rounded-lg bg-[rgba(240,180,41,0.05)] border border-[#F0B429]/20">
              <h4 className="font-medium text-[#EDE9FE] mb-1">ENTERPRISE</h4>
              <p className="text-2xl font-bold text-[#F0B429]">TT$4,500<span className="text-sm font-normal">/mes</span></p>
              <p className="text-xs text-[rgba(167,139,250,0.5)] mb-3">11+ enfermeras</p>
              <ul className="text-xs text-[#9D7BEA] space-y-1">
                <li>✓ Todo ilimitado</li>
                <li>✓ Multi-sede</li>
                <li>✓ API access</li>
                <li>✓ Soporte 24/7</li>
              </ul>
            </div>
          </div>
          <p className="text-xs text-[rgba(167,139,250,0.4)] text-center mt-4">
            Activación: TT$1,250 único • Descuento anual: 15% + 1 mes gratis
          </p>
        </div>

        {/* Clinic Modules */}
        <div className="p-6 rounded-xl bg-[rgba(108,63,206,0.05)] border border-[rgba(167,139,250,0.1)] backdrop-blur-lg mb-8">
          <h3 className="text-lg font-semibold text-[#EDE9FE] mb-4 flex items-center gap-2">
            <Hospital className="w-5 h-5 text-[#22D3EE]" />
            Módulos del Sistema de Clínica
          </h3>
          <div className="grid grid-cols-4 md:grid-cols-8 gap-3">
            {[
              { icon: Hospital, label: 'Dashboard', color: '#22D3EE' },
              { icon: Users, label: 'Pacientes', color: '#6C3FCE' },
              { icon: Calendar, label: 'Citas', color: '#F0B429' },
              { icon: DollarSign, label: 'Facturación', color: '#34D399' },
              { icon: Pill, label: 'Recetas', color: '#C026D3' },
              { icon: FlaskConical, label: 'Lab', color: '#3B82F6' },
              { icon: Package, label: 'Inventario', color: '#F87171' },
              { icon: BarChart3, label: 'Reportes', color: '#22D3EE' },
            ].map((module, index) => (
              <Link href="/clinic" key={index} className="group">
                <div className="p-3 rounded-lg bg-[rgba(108,63,206,0.07)] hover:bg-[rgba(108,63,206,0.15)] transition-colors text-center">
                  <module.icon className="w-6 h-6 mx-auto mb-2" style={{ color: module.color }} />
                  <span className="text-xs text-[#9D7BEA] group-hover:text-[#EDE9FE]">{module.label}</span>
                </div>
              </Link>
            ))}
          </div>
        </div>

        {/* Credentials */}
        <div className="p-6 rounded-xl bg-[rgba(108,63,206,0.05)] border border-[rgba(167,139,250,0.1)] backdrop-blur-lg">
          <h3 className="text-lg font-semibold text-[#EDE9FE] mb-4 flex items-center gap-2">
            <Settings className="w-5 h-5 text-[#9D7BEA]" />
            Credenciales de Acceso (Demo)
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 rounded-lg bg-[rgba(240,180,41,0.1)] border border-[#F0B429]/20">
              <div className="flex items-center gap-2 mb-2">
                <Shield className="w-4 h-4 text-[#F0B429]" />
                <span className="font-medium text-[#EDE9FE]">Super Admin (Dueño)</span>
              </div>
              <p className="text-sm text-[#9D7BEA] font-mono">admin@nexusos.tt</p>
              <p className="text-sm text-[#9D7BEA] font-mono">admin123</p>
              <p className="text-xs text-[rgba(167,139,250,0.5)] mt-2">Acceso total: Torre de Control + todo</p>
            </div>
            <div className="p-4 rounded-lg bg-[rgba(34,211,238,0.1)] border border-[#22D3EE]/20">
              <div className="flex items-center gap-2 mb-2">
                <Hospital className="w-4 h-4 text-[#22D3EE]" />
                <span className="font-medium text-[#EDE9FE]">Admin de Clínica (Tenant)</span>
              </div>
              <p className="text-sm text-[#9D7BEA] font-mono">clinic@demo.tt</p>
              <p className="text-sm text-[#9D7BEA] font-mono">demo123</p>
              <p className="text-xs text-[rgba(167,139,250,0.5)] mt-2">Acceso: Sistema de Clínica + Portal Enfermería</p>
            </div>
          </div>
        </div>

      </main>

      {/* Footer */}
      <footer className="relative z-10 border-t border-[rgba(167,139,250,0.1)] bg-[#0A0820]/50 mt-12">
        <div className="max-w-7xl mx-auto px-4 py-6 text-center">
          <p className="text-sm text-[#9D7BEA]">
            NexusOS © 2024 — Sistema de Gestión Empresarial para el Caribe
          </p>
        </div>
      </footer>
    </div>
  );
}
