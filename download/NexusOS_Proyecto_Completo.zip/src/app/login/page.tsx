'use client';

import React, { useState } from 'react';
import { AuthProvider, useAuth } from '@/lib/auth';
import { useRouter } from 'next/navigation';
import { Shield, Mail, Lock, Eye, EyeOff, AlertCircle } from 'lucide-react';

function LoginForm() {
  const { login, isLoading, error } = useAuth();
  const [email, setEmail] = useState('clinic@demo.tt');
  const [password, setPassword] = useState('demo123');
  const [showPassword, setShowPassword] = useState(false);
  const router = useRouter();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const result = await login(email, password);
    if (result.success) {
      if (result.role === 'SUPER_ADMIN') {
        router.push('/admin');
      } else {
        router.push('/clinic');
      }
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#050410] p-4">
      <div className="aurora-bg" />
      <div className="relative z-10 w-full max-w-md">
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#6C3FCE] to-[#C026D3] flex items-center justify-center mx-auto mb-4">
            <Shield className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-[#EDE9FE]" style={{ fontFamily: 'var(--font-cormorant)' }}>
            NexusOS
          </h1>
          <p className="text-[#9D7BEA] text-sm mt-1">Sistema de Gestión</p>
        </div>

        <div className="glass-card p-6">
          <form onSubmit={handleSubmit} className="space-y-4">
            {error && (
              <div className="flex items-center gap-2 p-3 rounded-lg bg-[#F87171]/10 border border-[#F87171]/20 text-[#F87171] text-sm">
                <AlertCircle className="w-4 h-4" />
                {error}
              </div>
            )}

            <div className="space-y-2">
              <label className="text-sm text-[#9D7BEA]">Email</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[rgba(167,139,250,0.5)]" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 rounded-lg bg-[rgba(108,63,206,0.07)] border border-[rgba(167,139,250,0.2)] text-[#EDE9FE] placeholder-[rgba(167,139,250,0.3)] focus:border-[#6C3FCE] focus:outline-none transition-colors"
                  placeholder="correo@ejemplo.com"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm text-[#9D7BEA]">Contraseña</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[rgba(167,139,250,0.5)]" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-10 pr-10 py-3 rounded-lg bg-[rgba(108,63,206,0.07)] border border-[rgba(167,139,250,0.2)] text-[#EDE9FE] placeholder-[rgba(167,139,250,0.3)] focus:border-[#6C3FCE] focus:outline-none transition-colors"
                  placeholder="••••••••"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-[rgba(167,139,250,0.5)] hover:text-[#9D7BEA]"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3 rounded-lg bg-gradient-to-r from-[#F0B429] to-[#d97706] text-white font-medium hover:opacity-90 transition-opacity disabled:opacity-50"
            >
              {isLoading ? 'Iniciando...' : 'Iniciar Sesión'}
            </button>
          </form>

          <div className="mt-6 pt-6 border-t border-[rgba(167,139,250,0.1)]">
            <p className="text-xs text-[rgba(167,139,250,0.5)] text-center mb-3">Credenciales de demostración:</p>
            <div className="space-y-2">
              <button
                type="button"
                onClick={() => { setEmail('admin@nexusos.tt'); setPassword('admin123'); }}
                className="w-full text-left p-2 rounded bg-[rgba(240,180,41,0.1)] text-[#F0B429] text-xs hover:bg-[rgba(240,180,41,0.2)] transition-colors"
              >
                👑 Admin: admin@nexusos.tt / admin123
              </button>
              <button
                type="button"
                onClick={() => { setEmail('clinic@demo.tt'); setPassword('demo123'); }}
                className="w-full text-left p-2 rounded bg-[rgba(34,211,238,0.1)] text-[#22D3EE] text-xs hover:bg-[rgba(34,211,238,0.2)] transition-colors"
              >
                🏥 Clínica: clinic@demo.tt / demo123
              </button>
            </div>
          </div>
        </div>

        <p className="text-center text-xs text-[rgba(167,139,250,0.3)] mt-6">
          <a href="/home" className="hover:text-[#9D7BEA]">← Volver al inicio</a>
        </p>
      </div>
    </div>
  );
}

export default function LoginPage() {
  return (
    <AuthProvider>
      <LoginForm />
    </AuthProvider>
  );
}
