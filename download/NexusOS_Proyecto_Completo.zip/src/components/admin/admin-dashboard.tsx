'use client';

import React, { useState } from 'react';
import { AdminLayout } from './admin-layout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  TrendingUp, 
  TrendingDown, 
  Users, 
  DollarSign, 
  Building2, 
  Activity,
  Lock,
  Globe,
  DollarSign as PriceIcon,
  Settings,
  Shield,
  Save,
  Eye,
  EyeOff,
  Key,
  Server,
  Mail,
  Bell,
  Palette,
  CheckCircle,
  AlertCircle,
  RefreshCw,
  Plus,
  Trash2,
  Edit3,
  Copy
} from 'lucide-react';

// Stat Card Component
function StatCard({ title, value, change, trend, icon: Icon }: {
  title: string;
  value: string;
  change?: string;
  trend?: 'up' | 'down';
  icon: React.ElementType;
}) {
  return (
    <div className="glass-card p-6">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-[var(--text-mid)] text-sm">{title}</p>
          <p className="text-2xl font-bold text-[var(--text-primary)] mt-1" style={{ fontFamily: 'var(--font-dm-mono)' }}>
            {value}
          </p>
          {change && (
            <p className={`text-sm mt-2 flex items-center gap-1 ${trend === 'up' ? 'text-[var(--success)]' : 'text-[var(--error)]'}`}>
              {trend === 'up' ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
              {change}
            </p>
          )}
        </div>
        <div className="w-12 h-12 rounded-xl bg-[var(--nexus-violet)]/10 flex items-center justify-center">
          <Icon className="w-6 h-6 text-[var(--nexus-violet-lite)]" />
        </div>
      </div>
    </div>
  );
}

// Password Management Section
function PasswordManagement() {
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [passwordData, setPasswordData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState('');

  const handlePasswordChange = () => {
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      setError('Las contraseñas no coinciden');
      return;
    }
    if (passwordData.newPassword.length < 8) {
      setError('La contraseña debe tener al menos 8 caracteres');
      return;
    }
    setSaved(true);
    setError('');
    setTimeout(() => setSaved(false), 3000);
    setPasswordData({ currentPassword: '', newPassword: '', confirmPassword: '' });
  };

  const users = [
    { id: '1', name: 'Dr. Martínez', email: 'drmartinez@clinic.com', role: 'Admin', lastLogin: '2026-03-25' },
    { id: '2', name: 'Ana Gómez', email: 'ana@bellavista.tt', role: 'User', lastLogin: '2026-03-24' },
    { id: '3', name: 'Carlos Pérez', email: 'carlos@elsol.tt', role: 'User', lastLogin: '2026-03-23' },
  ];

  return (
    <div className="space-y-6">
      {/* Change Own Password */}
      <div className="glass-card p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-lg bg-[var(--nexus-violet)]/10 flex items-center justify-center">
            <Lock className="w-5 h-5 text-[var(--nexus-violet-lite)]" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-[var(--text-primary)]">Cambiar Mi Contraseña</h3>
            <p className="text-sm text-[var(--text-dim)]">Actualiza tu contraseña de acceso</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="space-y-2">
            <Label className="text-[var(--text-mid)]">Contraseña Actual</Label>
            <div className="relative">
              <Input
                type={showCurrentPassword ? 'text' : 'password'}
                value={passwordData.currentPassword}
                onChange={(e) => setPasswordData(prev => ({ ...prev, currentPassword: e.target.value }))}
                placeholder="••••••••"
                className="pr-10"
              />
              <button
                type="button"
                onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-[var(--text-dim)] hover:text-[var(--text-primary)]"
              >
                {showCurrentPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <div className="space-y-2">
            <Label className="text-[var(--text-mid)]">Nueva Contraseña</Label>
            <div className="relative">
              <Input
                type={showNewPassword ? 'text' : 'password'}
                value={passwordData.newPassword}
                onChange={(e) => setPasswordData(prev => ({ ...prev, newPassword: e.target.value }))}
                placeholder="••••••••"
                className="pr-10"
              />
              <button
                type="button"
                onClick={() => setShowNewPassword(!showNewPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-[var(--text-dim)] hover:text-[var(--text-primary)]"
              >
                {showNewPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <div className="space-y-2">
            <Label className="text-[var(--text-mid)]">Confirmar Contraseña</Label>
            <div className="relative">
              <Input
                type={showConfirmPassword ? 'text' : 'password'}
                value={passwordData.confirmPassword}
                onChange={(e) => setPasswordData(prev => ({ ...prev, confirmPassword: e.target.value }))}
                placeholder="••••••••"
                className="pr-10"
              />
              <button
                type="button"
                onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-[var(--text-dim)] hover:text-[var(--text-primary)]"
              >
                {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>
        </div>

        {error && (
          <div className="mt-4 flex items-center gap-2 text-[var(--error)] text-sm">
            <AlertCircle className="w-4 h-4" />
            {error}
          </div>
        )}

        {saved && (
          <div className="mt-4 flex items-center gap-2 text-[var(--success)] text-sm">
            <CheckCircle className="w-4 h-4" />
            Contraseña actualizada exitosamente
          </div>
        )}

        <div className="flex justify-end mt-4">
          <Button onClick={handlePasswordChange} className="btn-nexus">
            <Save className="w-4 h-4 mr-2" />
            Actualizar Contraseña
          </Button>
        </div>
      </div>

      {/* Reset User Passwords */}
      <div className="glass-card p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-[var(--nexus-gold)]/10 flex items-center justify-center">
              <Key className="w-5 h-5 text-[var(--nexus-gold)]" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-[var(--text-primary)]">Restablecer Contraseñas de Usuarios</h3>
              <p className="text-sm text-[var(--text-dim)]">Genera contraseñas temporales para usuarios</p>
            </div>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-[var(--glass-border)]">
                <th className="text-left py-3 text-sm font-medium text-[var(--text-mid)]">Usuario</th>
                <th className="text-left py-3 text-sm font-medium text-[var(--text-mid)]">Email</th>
                <th className="text-left py-3 text-sm font-medium text-[var(--text-mid)]">Rol</th>
                <th className="text-left py-3 text-sm font-medium text-[var(--text-mid)]">Último Acceso</th>
                <th className="text-right py-3 text-sm font-medium text-[var(--text-mid)]">Acciones</th>
              </tr>
            </thead>
            <tbody>
              {users.map((user) => (
                <tr key={user.id} className="border-b border-[var(--glass-border)] last:border-0">
                  <td className="py-3">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[var(--nexus-violet)] to-[var(--nexus-fuchsia)] flex items-center justify-center">
                        <span className="text-white text-sm font-medium">{user.name.charAt(0)}</span>
                      </div>
                      <span className="text-[var(--text-primary)]">{user.name}</span>
                    </div>
                  </td>
                  <td className="py-3 text-sm text-[var(--text-mid)]">{user.email}</td>
                  <td className="py-3">
                    <span className={`px-2 py-1 rounded text-xs ${
                      user.role === 'Admin' 
                        ? 'bg-[var(--nexus-violet)]/10 text-[var(--nexus-violet-lite)]' 
                        : 'bg-[var(--glass)] text-[var(--text-mid)]'
                    }`}>
                      {user.role}
                    </span>
                  </td>
                  <td className="py-3 text-sm text-[var(--text-dim)]">{user.lastLogin}</td>
                  <td className="py-3 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <Button variant="outline" size="sm">
                        <RefreshCw className="w-3 h-3 mr-1" />
                        Reset
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// Domain Configuration Panel
function DomainConfiguration() {
  const [domains, setDomains] = useState([
    { id: '1', domain: 'app.nexusos.tt', status: 'active', ssl: true, primary: true },
    { id: '2', domain: 'clinic.nexusos.tt', status: 'active', ssl: true, primary: false },
    { id: '3', domain: 'portal.nexusos.tt', status: 'pending', ssl: false, primary: false },
  ]);
  const [newDomain, setNewDomain] = useState('');
  const [saved, setSaved] = useState(false);

  const handleAddDomain = () => {
    if (newDomain) {
      setDomains(prev => [...prev, {
        id: Date.now().toString(),
        domain: newDomain,
        status: 'pending',
        ssl: false,
        primary: false
      }]);
      setNewDomain('');
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    }
  };

  const handleSetPrimary = (id: string) => {
    setDomains(prev => prev.map(d => ({
      ...d,
      primary: d.id === id
    })));
  };

  return (
    <div className="space-y-6">
      {/* Domain Settings */}
      <div className="glass-card p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-lg bg-[var(--nexus-aqua)]/10 flex items-center justify-center">
            <Globe className="w-5 h-5 text-[var(--nexus-aqua)]" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-[var(--text-primary)]">Configuración de Dominios</h3>
            <p className="text-sm text-[var(--text-dim)]">Gestiona los dominios personalizados del sistema</p>
          </div>
        </div>

        {/* Add New Domain */}
        <div className="flex gap-4 mb-6">
          <div className="flex-1">
            <Input
              value={newDomain}
              onChange={(e) => setNewDomain(e.target.value)}
              placeholder="nuevo-dominio.com"
              className="w-full"
            />
          </div>
          <Button onClick={handleAddDomain} className="btn-nexus">
            <Plus className="w-4 h-4 mr-2" />
            Agregar Dominio
          </Button>
        </div>

        {saved && (
          <div className="mb-4 flex items-center gap-2 text-[var(--success)] text-sm">
            <CheckCircle className="w-4 h-4" />
            Dominio agregado exitosamente
          </div>
        )}

        {/* Domain List */}
        <div className="space-y-3">
          {domains.map((domain) => (
            <div key={domain.id} className="flex items-center justify-between p-4 rounded-lg bg-[var(--glass)]">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-lg bg-[var(--obsidian-3)] flex items-center justify-center">
                  <Server className="w-5 h-5 text-[var(--text-mid)]" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <p className="text-[var(--text-primary)] font-mono">{domain.domain}</p>
                    {domain.primary && (
                      <span className="px-2 py-0.5 rounded text-xs bg-[var(--nexus-gold)]/10 text-[var(--nexus-gold)]">
                        Primario
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-3 mt-1">
                    <span className={`text-xs flex items-center gap-1 ${
                      domain.status === 'active' ? 'text-[var(--success)]' : 'text-[var(--nexus-gold)]'
                    }`}>
                      <span className={`w-2 h-2 rounded-full ${
                        domain.status === 'active' ? 'bg-[var(--success)]' : 'bg-[var(--nexus-gold)]'
                      }`} />
                      {domain.status === 'active' ? 'Activo' : 'Pendiente'}
                    </span>
                    <span className={`text-xs flex items-center gap-1 ${
                      domain.ssl ? 'text-[var(--success)]' : 'text-[var(--error)]'
                    }`}>
                      <Shield className="w-3 h-3" />
                      SSL {domain.ssl ? 'Activo' : 'Inactivo'}
                    </span>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {!domain.primary && (
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => handleSetPrimary(domain.id)}
                  >
                    <Globe className="w-3 h-3 mr-1" />
                    Primario
                  </Button>
                )}
                <Button variant="outline" size="sm">
                  <Edit3 className="w-3 h-3" />
                </Button>
                <Button variant="outline" size="sm" className="text-[var(--error)] hover:text-[var(--error)]">
                  <Trash2 className="w-3 h-3" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* DNS Configuration */}
      <div className="glass-card p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-lg bg-[var(--nexus-violet)]/10 flex items-center justify-center">
            <Server className="w-5 h-5 text-[var(--nexus-violet-lite)]" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-[var(--text-primary)]">Configuración DNS</h3>
            <p className="text-sm text-[var(--text-dim)]">Registros DNS para configuración de dominios</p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="p-4 rounded-lg bg-[var(--glass)] space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-[var(--text-mid)]">Registro A</p>
                <p className="font-mono text-sm text-[var(--text-primary)]">@ → 192.168.1.100</p>
              </div>
              <Button variant="ghost" size="sm">
                <Copy className="w-4 h-4" />
              </Button>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-[var(--text-mid)]">Registro CNAME</p>
                <p className="font-mono text-sm text-[var(--text-primary)]">www → nexusos.tt</p>
              </div>
              <Button variant="ghost" size="sm">
                <Copy className="w-4 h-4" />
              </Button>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-[var(--text-mid)]">Registro MX</p>
                <p className="font-mono text-sm text-[var(--text-primary)]">mail → mail.nexusos.tt</p>
              </div>
              <Button variant="ghost" size="sm">
                <Copy className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// Price Editing Interface
function PriceEditingInterface() {
  const [prices, setPrices] = useState({
    starter: { monthly: 500, annual: 400, activation: 1250 },
    growth: { monthly: 1200, annual: 960, activation: 1250 },
    premium: { monthly: 2500, annual: 2000, activation: 1250 },
  });
  const [currency, setCurrency] = useState('TTD');
  const [taxRate, setTaxRate] = useState(12.5);
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  return (
    <div className="space-y-6">
      {/* Global Settings */}
      <div className="glass-card p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-lg bg-[var(--nexus-gold)]/10 flex items-center justify-center">
            <PriceIcon className="w-5 h-5 text-[var(--nexus-gold)]" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-[var(--text-primary)]">Configuración Global de Precios</h3>
            <p className="text-sm text-[var(--text-dim)]">Ajusta moneda, impuestos y descuentos</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="space-y-2">
            <Label className="text-[var(--text-mid)]">Moneda Principal</Label>
            <select 
              value={currency}
              onChange={(e) => setCurrency(e.target.value)}
              className="w-full h-10 px-3 rounded-lg bg-[var(--obsidian-3)] border border-[var(--glass-border)] text-[var(--text-primary)]"
            >
              <option value="TTD">TTD - Dólar Trinitense</option>
              <option value="USD">USD - Dólar Americano</option>
              <option value="GYD">GYD - Dólar Guyanés</option>
            </select>
          </div>

          <div className="space-y-2">
            <Label className="text-[var(--text-mid)]">Tasa de Impuesto (%)</Label>
            <Input
              type="number"
              value={taxRate}
              onChange={(e) => setTaxRate(parseFloat(e.target.value))}
              step="0.1"
              className="font-mono"
            />
          </div>

          <div className="space-y-2">
            <Label className="text-[var(--text-mid)]">Descuento Anual (%)</Label>
            <Input
              type="number"
              defaultValue="20"
              className="font-mono"
            />
          </div>
        </div>
      </div>

      {/* Plans Pricing */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {Object.entries(prices).map(([plan, pricing]) => (
          <div key={plan} className="glass-card p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-[var(--text-primary)] uppercase">{plan}</h3>
              <span className={`px-2 py-1 rounded text-xs ${
                plan === 'growth' ? 'bg-[var(--nexus-gold)]/10 text-[var(--nexus-gold)]' : 'bg-[var(--glass)] text-[var(--text-mid)]'
              }`}>
                {plan === 'growth' ? 'Popular' : plan === 'premium' ? 'Enterprise' : 'Básico'}
              </span>
            </div>

            <div className="space-y-4">
              <div className="space-y-2">
                <Label className="text-[var(--text-mid)] text-sm">Precio Mensual ({currency})</Label>
                <Input
                  type="number"
                  value={pricing.monthly}
                  onChange={(e) => setPrices(prev => ({
                    ...prev,
                    [plan]: { ...prev[plan as keyof typeof prev], monthly: parseFloat(e.target.value) }
                  }))}
                  className="font-mono"
                />
              </div>

              <div className="space-y-2">
                <Label className="text-[var(--text-mid)] text-sm">Precio Anual ({currency})</Label>
                <Input
                  type="number"
                  value={pricing.annual}
                  onChange={(e) => setPrices(prev => ({
                    ...prev,
                    [plan]: { ...prev[plan as keyof typeof prev], annual: parseFloat(e.target.value) }
                  }))}
                  className="font-mono"
                />
              </div>

              <div className="space-y-2">
                <Label className="text-[var(--text-mid)] text-sm">Activación ({currency})</Label>
                <Input
                  type="number"
                  value={pricing.activation}
                  onChange={(e) => setPrices(prev => ({
                    ...prev,
                    [plan]: { ...prev[plan as keyof typeof prev], activation: parseFloat(e.target.value) }
                  }))}
                  className="font-mono"
                />
              </div>
            </div>

            <div className="mt-4 pt-4 border-t border-[var(--glass-border)]">
              <div className="flex justify-between text-xs text-[var(--text-dim)]">
                <span>Con impuesto:</span>
                <span className="font-mono text-[var(--text-primary)]">
                  {(pricing.monthly * (1 + taxRate / 100)).toFixed(2)} {currency}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {saved && (
        <div className="flex items-center gap-2 text-[var(--success)] text-sm">
          <CheckCircle className="w-4 h-4" />
          Precios actualizados exitosamente
        </div>
      )}

      <div className="flex justify-end">
        <Button onClick={handleSave} className="btn-gold">
          <Save className="w-4 h-4 mr-2" />
          Guardar Cambios
        </Button>
      </div>
    </div>
  );
}

// System Settings Editor
function SystemSettingsEditor() {
  const [settings, setSettings] = useState({
    siteName: 'NexusOS',
    supportEmail: 'soporte@nexusos.tt',
    timezone: 'America/Port_of_Spain',
    dateFormat: 'DD/MM/YYYY',
    language: 'es',
    maintenanceMode: false,
    registrationEnabled: true,
    emailNotifications: true,
    smsNotifications: false,
    twoFactorRequired: false,
    sessionTimeout: 30,
    maxLoginAttempts: 5,
  });
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  return (
    <div className="space-y-6">
      {/* General Settings */}
      <div className="glass-card p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-lg bg-[var(--nexus-violet)]/10 flex items-center justify-center">
            <Settings className="w-5 h-5 text-[var(--nexus-violet-lite)]" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-[var(--text-primary)]">Configuración General</h3>
            <p className="text-sm text-[var(--text-dim)]">Ajustes básicos del sistema</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <Label className="text-[var(--text-mid)]">Nombre del Sitio</Label>
            <Input
              value={settings.siteName}
              onChange={(e) => setSettings(prev => ({ ...prev, siteName: e.target.value }))}
            />
          </div>

          <div className="space-y-2">
            <Label className="text-[var(--text-mid)]">Email de Soporte</Label>
            <Input
              type="email"
              value={settings.supportEmail}
              onChange={(e) => setSettings(prev => ({ ...prev, supportEmail: e.target.value }))}
            />
          </div>

          <div className="space-y-2">
            <Label className="text-[var(--text-mid)]">Zona Horaria</Label>
            <select 
              value={settings.timezone}
              onChange={(e) => setSettings(prev => ({ ...prev, timezone: e.target.value }))}
              className="w-full h-10 px-3 rounded-lg bg-[var(--obsidian-3)] border border-[var(--glass-border)] text-[var(--text-primary)]"
            >
              <option value="America/Port_of_Spain">América/Puerto España (AST)</option>
              <option value="America/New_York">América/Nueva York (EST)</option>
              <option value="UTC">UTC</option>
            </select>
          </div>

          <div className="space-y-2">
            <Label className="text-[var(--text-mid)]">Formato de Fecha</Label>
            <select 
              value={settings.dateFormat}
              onChange={(e) => setSettings(prev => ({ ...prev, dateFormat: e.target.value }))}
              className="w-full h-10 px-3 rounded-lg bg-[var(--obsidian-3)] border border-[var(--glass-border)] text-[var(--text-primary)]"
            >
              <option value="DD/MM/YYYY">DD/MM/YYYY</option>
              <option value="MM/DD/YYYY">MM/DD/YYYY</option>
              <option value="YYYY-MM-DD">YYYY-MM-DD</option>
            </select>
          </div>

          <div className="space-y-2">
            <Label className="text-[var(--text-mid)]">Idioma Principal</Label>
            <select 
              value={settings.language}
              onChange={(e) => setSettings(prev => ({ ...prev, language: e.target.value }))}
              className="w-full h-10 px-3 rounded-lg bg-[var(--obsidian-3)] border border-[var(--glass-border)] text-[var(--text-primary)]"
            >
              <option value="es">Español</option>
              <option value="en">English</option>
            </select>
          </div>

          <div className="space-y-2">
            <Label className="text-[var(--text-mid)]">Timeout de Sesión (minutos)</Label>
            <Input
              type="number"
              value={settings.sessionTimeout}
              onChange={(e) => setSettings(prev => ({ ...prev, sessionTimeout: parseInt(e.target.value) }))}
            />
          </div>
        </div>
      </div>

      {/* Security Settings */}
      <div className="glass-card p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-lg bg-[var(--nexus-aqua)]/10 flex items-center justify-center">
            <Shield className="w-5 h-5 text-[var(--nexus-aqua)]" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-[var(--text-primary)]">Configuración de Seguridad</h3>
            <p className="text-sm text-[var(--text-dim)]">Control de acceso y autenticación</p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 rounded-lg bg-[var(--glass)]">
            <div className="flex items-center gap-3">
              <Lock className="w-5 h-5 text-[var(--text-mid)]" />
              <div>
                <p className="text-[var(--text-primary)]">Autenticación de Dos Factores</p>
                <p className="text-xs text-[var(--text-dim)]">Requerir 2FA para todos los usuarios</p>
              </div>
            </div>
            <Switch
              checked={settings.twoFactorRequired}
              onCheckedChange={(checked) => setSettings(prev => ({ ...prev, twoFactorRequired: checked }))}
            />
          </div>

          <div className="flex items-center justify-between p-4 rounded-lg bg-[var(--glass)]">
            <div className="flex items-center gap-3">
              <Users className="w-5 h-5 text-[var(--text-mid)]" />
              <div>
                <p className="text-[var(--text-primary)]">Registro de Usuarios</p>
                <p className="text-xs text-[var(--text-dim)]">Permitir auto-registro de nuevos usuarios</p>
              </div>
            </div>
            <Switch
              checked={settings.registrationEnabled}
              onCheckedChange={(checked) => setSettings(prev => ({ ...prev, registrationEnabled: checked }))}
            />
          </div>

          <div className="flex items-center justify-between p-4 rounded-lg bg-[var(--glass)]">
            <div className="flex items-center gap-3">
              <AlertCircle className="w-5 h-5 text-[var(--text-mid)]" />
              <div>
                <p className="text-[var(--text-primary)]">Modo Mantenimiento</p>
                <p className="text-xs text-[var(--text-dim)]">Desactivar acceso al sistema temporalmente</p>
              </div>
            </div>
            <Switch
              checked={settings.maintenanceMode}
              onCheckedChange={(checked) => setSettings(prev => ({ ...prev, maintenanceMode: checked }))}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-[var(--text-mid)]">Máx. Intentos de Login</Label>
              <Input
                type="number"
                value={settings.maxLoginAttempts}
                onChange={(e) => setSettings(prev => ({ ...prev, maxLoginAttempts: parseInt(e.target.value) }))}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Notifications Settings */}
      <div className="glass-card p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-lg bg-[var(--nexus-gold)]/10 flex items-center justify-center">
            <Bell className="w-5 h-5 text-[var(--nexus-gold)]" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-[var(--text-primary)]">Configuración de Notificaciones</h3>
            <p className="text-sm text-[var(--text-dim)]">Preferencias de comunicación del sistema</p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 rounded-lg bg-[var(--glass)]">
            <div className="flex items-center gap-3">
              <Mail className="w-5 h-5 text-[var(--text-mid)]" />
              <div>
                <p className="text-[var(--text-primary)]">Notificaciones por Email</p>
                <p className="text-xs text-[var(--text-dim)]">Enviar alertas y actualizaciones por correo</p>
              </div>
            </div>
            <Switch
              checked={settings.emailNotifications}
              onCheckedChange={(checked) => setSettings(prev => ({ ...prev, emailNotifications: checked }))}
            />
          </div>

          <div className="flex items-center justify-between p-4 rounded-lg bg-[var(--glass)]">
            <div className="flex items-center gap-3">
              <Bell className="w-5 h-5 text-[var(--text-mid)]" />
              <div>
                <p className="text-[var(--text-primary)]">Notificaciones SMS</p>
                <p className="text-xs text-[var(--text-dim)]">Enviar alertas urgentes por mensaje de texto</p>
              </div>
            </div>
            <Switch
              checked={settings.smsNotifications}
              onCheckedChange={(checked) => setSettings(prev => ({ ...prev, smsNotifications: checked }))}
            />
          </div>
        </div>
      </div>

      {saved && (
        <div className="flex items-center gap-2 text-[var(--success)] text-sm">
          <CheckCircle className="w-4 h-4" />
          Configuración guardada exitosamente
        </div>
      )}

      <div className="flex justify-end">
        <Button onClick={handleSave} className="btn-gold">
          <Save className="w-4 h-4 mr-2" />
          Guardar Configuración
        </Button>
      </div>
    </div>
  );
}

// Recent Orders Table
function RecentOrders() {
  const orders = [
    { id: 'NXS-2026-0001', business: 'Clínica San Fernando', plan: 'Growth', amount: 'TT$2,450', status: 'active' },
    { id: 'NXS-2026-0002', business: 'Panadería Doña María', plan: 'Starter', amount: 'TT$1,750', status: 'pending' },
    { id: 'NXS-2026-0003', business: 'Salón Bella Vista', plan: 'Premium', amount: 'TT$3,750', status: 'active' },
  ];

  const statusColors: Record<string, string> = {
    active: 'bg-[var(--success)]/10 text-[var(--success)]',
    pending: 'bg-[var(--nexus-gold)]/10 text-[var(--nexus-gold)]',
    failed: 'bg-[var(--error)]/10 text-[var(--error)]',
  };

  return (
    <div className="glass-card p-6">
      <h3 className="text-lg font-semibold text-[var(--text-primary)] mb-4">Órdenes Recientes</h3>
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-[var(--glass-border)]">
              <th className="text-left py-3 text-sm font-medium text-[var(--text-mid)]">Orden</th>
              <th className="text-left py-3 text-sm font-medium text-[var(--text-mid)]">Negocio</th>
              <th className="text-left py-3 text-sm font-medium text-[var(--text-mid)]">Plan</th>
              <th className="text-left py-3 text-sm font-medium text-[var(--text-mid)]">Monto</th>
              <th className="text-left py-3 text-sm font-medium text-[var(--text-mid)]">Estado</th>
            </tr>
          </thead>
          <tbody>
            {orders.map((order) => (
              <tr key={order.id} className="border-b border-[var(--glass-border)] last:border-0">
                <td className="py-3 text-sm text-[var(--nexus-violet-lite)] font-mono">{order.id}</td>
                <td className="py-3 text-sm text-[var(--text-primary)]">{order.business}</td>
                <td className="py-3 text-sm text-[var(--text-mid)]">{order.plan}</td>
                <td className="py-3 text-sm text-[var(--text-primary)] font-mono">{order.amount}</td>
                <td className="py-3">
                  <span className={`px-2 py-1 rounded text-xs ${statusColors[order.status]}`}>
                    {order.status === 'active' ? 'Activo' : order.status === 'pending' ? 'Pendiente' : 'Fallido'}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// Tenants List
function TenantsList() {
  const tenants = [
    { name: 'Clínica San Fernando', industry: 'Salud', users: 8, status: 'active' },
    { name: 'Salón Bella Vista', industry: 'Belleza', users: 4, status: 'active' },
    { name: 'Panadería Doña María', industry: 'Alimentos', users: 2, status: 'trial' },
  ];

  return (
    <div className="glass-card p-6">
      <h3 className="text-lg font-semibold text-[var(--text-primary)] mb-4">Inquilinos Activos</h3>
      <div className="space-y-3">
        {tenants.map((tenant, index) => (
          <div key={index} className="flex items-center justify-between p-3 rounded-lg bg-[var(--glass)]">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[var(--nexus-violet)] to-[var(--nexus-fuchsia)] flex items-center justify-center">
                <span className="text-white font-bold text-sm">{tenant.name.charAt(0)}</span>
              </div>
              <div>
                <p className="text-sm font-medium text-[var(--text-primary)]">{tenant.name}</p>
                <p className="text-xs text-[var(--text-dim)]">{tenant.industry}</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-sm text-[var(--text-mid)]">{tenant.users} usuarios</p>
              <span className={`text-xs ${tenant.status === 'active' ? 'text-[var(--success)]' : 'text-[var(--nexus-gold)]'}`}>
                {tenant.status === 'active' ? '● Activo' : '● Prueba'}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export function AdminDashboard() {
  const [activeSettingsTab, setActiveSettingsTab] = useState('password');

  return (
    <AdminLayout activeTab="dashboard">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard
          title="Ingresos del Mes"
          value="TT$45,500"
          change="+12.5% vs mes anterior"
          trend="up"
          icon={DollarSign}
        />
        <StatCard
          title="Inquilinos Activos"
          value="23"
          change="+3 nuevos"
          trend="up"
          icon={Building2}
        />
        <StatCard
          title="Usuarios Totales"
          value="156"
          change="+18 esta semana"
          trend="up"
          icon={Users}
        />
        <StatCard
          title="Tasa de Actividad"
          value="94%"
          change="-2% vs semana anterior"
          trend="down"
          icon={Activity}
        />
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        <div className="lg:col-span-2">
          <RecentOrders />
        </div>
        <div>
          <TenantsList />
        </div>
      </div>

      {/* Settings Section */}
      <div className="glass-card p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[var(--nexus-violet)] to-[var(--nexus-fuchsia)] flex items-center justify-center">
            <Settings className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-[var(--text-primary)]">Centro de Configuración</h2>
            <p className="text-sm text-[var(--text-dim)]">Gestiona contraseñas, dominios, precios y sistema</p>
          </div>
        </div>

        <Tabs value={activeSettingsTab} onValueChange={setActiveSettingsTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-6 bg-[var(--obsidian-3)]">
            <TabsTrigger value="password" className="flex items-center gap-2 data-[state=active]:bg-[var(--nexus-violet)]/20">
              <Lock className="w-4 h-4" />
              <span className="hidden sm:inline">Contraseñas</span>
            </TabsTrigger>
            <TabsTrigger value="domains" className="flex items-center gap-2 data-[state=active]:bg-[var(--nexus-violet)]/20">
              <Globe className="w-4 h-4" />
              <span className="hidden sm:inline">Dominios</span>
            </TabsTrigger>
            <TabsTrigger value="pricing" className="flex items-center gap-2 data-[state=active]:bg-[var(--nexus-violet)]/20">
              <DollarSign className="w-4 h-4" />
              <span className="hidden sm:inline">Precios</span>
            </TabsTrigger>
            <TabsTrigger value="system" className="flex items-center gap-2 data-[state=active]:bg-[var(--nexus-violet)]/20">
              <Settings className="w-4 h-4" />
              <span className="hidden sm:inline">Sistema</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="password" className="mt-0">
            <PasswordManagement />
          </TabsContent>

          <TabsContent value="domains" className="mt-0">
            <DomainConfiguration />
          </TabsContent>

          <TabsContent value="pricing" className="mt-0">
            <PriceEditingInterface />
          </TabsContent>

          <TabsContent value="system" className="mt-0">
            <SystemSettingsEditor />
          </TabsContent>
        </Tabs>
      </div>
    </AdminLayout>
  );
}
