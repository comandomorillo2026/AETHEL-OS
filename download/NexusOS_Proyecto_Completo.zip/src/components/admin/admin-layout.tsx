'use client';

import React from 'react';
import { useAuth } from '@/lib/auth';
import { 
  LayoutDashboard, 
  Users, 
  Building2, 
  CreditCard, 
  Settings, 
  LogOut,
  Bell
} from 'lucide-react';

interface AdminLayoutProps {
  children: React.ReactNode;
  activeTab?: string;
}

export function AdminLayout({ children, activeTab = 'dashboard' }: AdminLayoutProps) {
  const { user, logout } = useAuth();

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'orders', label: 'Órdenes', icon: CreditCard },
    { id: 'tenants', label: 'Inquilinos', icon: Building2 },
    { id: 'users', label: 'Usuarios', icon: Users },
    { id: 'settings', label: 'Configuración', icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-[var(--obsidian)] flex">
      {/* Sidebar */}
      <aside className="w-64 bg-[var(--obsidian-2)] border-r border-[var(--glass-border)] flex flex-col hidden md:flex">
        <div className="p-6 border-b border-[var(--glass-border)]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[var(--nexus-violet)] to-[var(--nexus-fuchsia)] flex items-center justify-center">
              <span className="text-white font-bold">N</span>
            </div>
            <div>
              <h1 className="font-bold text-[var(--text-primary)]" style={{ fontFamily: 'var(--font-cormorant)' }}>
                NexusOS
              </h1>
              <p className="text-xs text-[var(--nexus-gold)]">Torre de Control</p>
            </div>
          </div>
        </div>

        <nav className="flex-1 p-4">
          <ul className="space-y-1">
            {navItems.map((item) => (
              <li key={item.id}>
                <button
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors text-left ${
                    activeTab === item.id
                      ? 'bg-[var(--nexus-violet)]/20 text-[var(--nexus-violet-lite)]'
                      : 'text-[var(--text-mid)] hover:bg-[var(--glass)] hover:text-[var(--text-primary)]'
                  }`}
                >
                  <item.icon className="w-5 h-5" />
                  <span>{item.label}</span>
                </button>
              </li>
            ))}
          </ul>
        </nav>

        <div className="p-4 border-t border-[var(--glass-border)]">
          <div className="flex items-center gap-3 p-3 rounded-lg bg-[var(--glass)]">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[var(--nexus-gold)] to-[var(--nexus-fuchsia)] flex items-center justify-center">
              <span className="text-white font-bold text-sm">{user?.name?.charAt(0) || 'A'}</span>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-[var(--text-primary)] truncate">{user?.name}</p>
              <p className="text-xs text-[var(--text-dim)]">Super Admin</p>
            </div>
            <button onClick={logout} className="text-[var(--text-dim)] hover:text-[var(--error)] transition-colors">
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col">
        <header className="h-16 bg-[var(--obsidian-2)]/50 border-b border-[var(--glass-border)] flex items-center justify-between px-6">
          <h2 className="text-lg font-semibold text-[var(--text-primary)]">
            {navItems.find(item => item.id === activeTab)?.label || 'Dashboard'}
          </h2>
          <button className="relative p-2 rounded-lg hover:bg-[var(--glass)] transition-colors">
            <Bell className="w-5 h-5 text-[var(--text-mid)]" />
            <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-[var(--nexus-gold)]" />
          </button>
        </header>
        <div className="flex-1 p-6 overflow-auto">{children}</div>
      </main>
    </div>
  );
}
