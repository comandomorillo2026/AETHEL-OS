'use client';

import React, { createContext, useContext, useState, useCallback, ReactNode } from 'react';
import { User, AuthState } from './types';
import { DEMO_USERS, DEMO_PASSWORDS } from './types';

interface AuthContextType extends AuthState {
  login: (email: string, password: string) => Promise<{ success: boolean; role?: string }>;
  logout: () => void;
  isSuperAdmin: boolean;
  isTenant: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const login = useCallback(async (email: string, password: string): Promise<{ success: boolean; role?: string }> => {
    setIsLoading(true);
    
    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 500));
    
    const demoUser = DEMO_USERS[email.toLowerCase()];
    const demoPassword = DEMO_PASSWORDS[email.toLowerCase()];
    
    if (demoUser && demoPassword === password) {
      setUser(demoUser);
      setIsLoading(false);
      return { success: true, role: demoUser.role };
    }
    
    setIsLoading(false);
    return { success: false };
  }, []);

  const logout = useCallback(() => {
    setUser(null);
  }, []);

  const value: AuthContextType = {
    user,
    isAuthenticated: !!user,
    isLoading,
    login,
    logout,
    isSuperAdmin: user?.role === 'SUPER_ADMIN' || user?.role === 'ADMIN',
    isTenant: user?.role === 'TENANT_ADMIN' || user?.role === 'TENANT_USER',
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
}
